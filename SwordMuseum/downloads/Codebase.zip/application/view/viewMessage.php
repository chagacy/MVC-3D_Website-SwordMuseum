<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Message View</title>
</head>

<body>
	<h1> <?php echo $data ?> </h1>
</body>
</html>